<?php
if (!defined('ABSPATH')) exit;

class WC_Gateway_KashPay extends WC_Payment_Gateway {

  public function __construct() {
    $this->id                 = 'kashpay';
    $this->method_title       = 'PosPago';
    $this->method_description = 'Paga con PosPago (Link de pago) usando OrderReceiver.';
    $this->has_fields         = false;

    $this->supports = ['products'];

    $this->init_form_fields();
    $this->init_settings();

    $this->title       = $this->get_option('title');
    $this->description = $this->get_option('description');
    $this->enabled     = $this->get_option('enabled');

    // Logo en el checkout
    $this->icon = $this->get_icon_url();

    // Admin: guardar opciones
    add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);

    // Callback y webhook
    add_action('woocommerce_api_wc_kashpay_return', [$this, 'handle_return']);
    add_action('woocommerce_api_wc_kashpay_webhook', [$this, 'handle_webhook']);

    // === AUTO-VERIFICACIÓN ===
    add_action('woocommerce_thankyou_' . $this->id, [$this, 'check_order_on_thankyou']);
    add_action('woocommerce_view_order', [$this, 'check_order_on_view'], 1);
    add_action('kashpay_cron_check_pending_orders', [$this, 'cron_check_pending_orders']);

    if (!is_admin() && !wp_doing_cron()) {
      add_action('wp_loaded', [$this, 'check_pending_orders_for_current_user']);
    }

    // Limpiar token cacheado cuando se cambia de modo sandbox/producción
    add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'clear_cached_token_on_save']);
  }

  // =========================================================================
  //  LOGO & ICON
  // =========================================================================

  private function get_icon_url(): string {
    return untrailingslashit(plugin_dir_url(dirname(__FILE__))) . '/assets/pospago-logo.png';
  }

  public function get_icon(): string {
    $icon_url = esc_url($this->icon);
    $icon_html = '<img src="' . $icon_url . '" alt="' . esc_attr($this->get_title()) . '" style="max-height: 32px; width: auto; margin-left: 8px; vertical-align: middle;" />';
    return apply_filters('woocommerce_gateway_icon', $icon_html, $this->id);
  }

  // =========================================================================
  //  FORM FIELDS (Admin)
  // =========================================================================

  public function init_form_fields() {
    $this->form_fields = [
      'enabled' => [
        'title'   => 'Habilitar/Deshabilitar',
        'type'    => 'checkbox',
        'label'   => 'Habilitar PosPago',
        'default' => 'no',
      ],
      'title' => [
        'title'       => 'Título',
        'type'        => 'text',
        'default'     => 'PosPago',
        'description' => 'Nombre que ve el cliente en el checkout.',
      ],
      'description' => [
        'title'   => 'Descripción',
        'type'    => 'textarea',
        'default' => 'Paga de forma segura con PosPago.',
      ],
      'sandbox' => [
        'title'       => 'Modo de entorno',
        'type'        => 'checkbox',
        'label'       => 'Activar modo Sandbox (pruebas)',
        'default'     => 'no',
        'description' => 'Activado = Sandbox (pruebas). Desactivado = Producción (cobros reales).',
      ],

      // --- Credenciales de autenticación (producción: auto-generación de token) ---
      'auth_section' => [
        'title'       => 'Autenticación',
        'type'        => 'title',
        'description' => 'Credenciales para generar el Bearer Token automáticamente en producción. En Sandbox se usa el Bearer Token manual de abajo.',
      ],
      'auth_user' => [
        'title'       => 'Auth User',
        'type'        => 'text',
        'description' => 'Usuario de autenticación (sirioID del comercio). Se usa para auto-generar el token en producción.',
        'default'     => '',
      ],
      'auth_password' => [
        'title'       => 'Auth Password',
        'type'        => 'password',
        'description' => 'Contraseña de autenticación. Se usa para auto-generar el token en producción.',
        'default'     => '',
      ],
      'bearer_token' => [
        'title'       => 'Bearer Token (Sandbox)',
        'type'        => 'password',
        'description' => 'Token Bearer manual. Se usa solo en modo Sandbox. En producción el token se genera automáticamente.',
        'default'     => '',
      ],

      // --- Configuración del comercio ---
      'commerce_section' => [
        'title'       => 'Configuración del comercio',
        'type'        => 'title',
        'description' => '',
      ],
      'entity_i' => [
        'title'   => 'Entity-i',
        'type'    => 'text',
        'default' => 'com.onsigna',
      ],
      'sirio_id' => [
        'title'   => 'sirioID (comercio)',
        'type'    => 'text',
        'default' => '',
      ],
      'cashier_user' => [
        'title'   => 'user (cajero)',
        'type'    => 'text',
        'default' => '',
      ],
      'currency_code' => [
        'title'       => 'Currency (ISO num)',
        'type'        => 'text',
        'description' => 'MXN = 484',
        'default'     => '484',
      ],
      'payment_type' => [
        'title'   => 'paymentType',
        'type'    => 'select',
        'default' => '1',
        'options' => [
          '1' => '1 - COMPLETO',
          '2' => '2 - DIVIDIDO',
          '3' => '3 - MIXTO',
        ],
      ],
      'payment_method_id' => [
        'title'       => 'paymentMethodID',
        'type'        => 'text',
        'description' => 'Según tu comercio. En ejemplos aparece 5 (Tarjeta).',
        'default'     => '5',
      ],
      'expiration_minutes' => [
        'title'   => 'Expiración (minutos)',
        'type'    => 'number',
        'default' => 60,
      ],
      'debug' => [
        'title'   => 'Debug',
        'type'    => 'checkbox',
        'label'   => 'Escribir logs en WooCommerce Logs',
        'default' => 'no',
      ],
    ];
  }

  // =========================================================================
  //  API & LOGGING
  // =========================================================================

  private function api(): KashPay_API {
    $debug   = ($this->get_option('debug') === 'yes');
    $sandbox = ($this->get_option('sandbox') === 'yes');

    return new KashPay_API(
      (string) $this->get_option('bearer_token'),
      (string) $this->get_option('entity_i'),
      $debug,
      $sandbox,
      (string) $this->get_option('auth_user'),
      (string) $this->get_option('auth_password')
    );
  }

  /**
   * Limpia el token cacheado cuando se guardan los settings.
   */
  public function clear_cached_token_on_save(): void {
    delete_transient('kashpay_bearer_token');
    delete_transient('kashpay_bearer_token_expires');
  }

  private function log_info(string $msg): void {
    if ($this->get_option('debug') === 'yes' && function_exists('wc_get_logger')) {
      wc_get_logger()->info($msg, ['source' => 'kashpay']);
    }
  }

  private function log_error(string $msg): void {
    if ($this->get_option('debug') === 'yes' && function_exists('wc_get_logger')) {
      wc_get_logger()->error($msg, ['source' => 'kashpay']);
    }
  }

  // =========================================================================
  //  PROCESS PAYMENT
  // =========================================================================

  public function process_payment($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) {
      wc_add_notice('No se pudo iniciar el pago (pedido inválido).', 'error');
      return ['result' => 'failure'];
    }

    $sirio_id = trim((string) $this->get_option('sirio_id'));
    $cashier  = trim((string) $this->get_option('cashier_user'));

    if ($sirio_id === '' || $cashier === '') {
      wc_add_notice('PosPago no está configurado (sirioID/user).', 'error');
      return ['result' => 'failure'];
    }

    $existing = (string) $order->get_meta('_kashpay_order_id');
    if ($existing !== '') {
      $this->log_info('Existing _kashpay_order_id=' . $existing . ' - validating via GET');

      $check = $this->api()->get_order($existing);
      $this->log_info('Response get_order(existing): ' . wp_json_encode($check));

      if (!empty($check['ok']) && !empty($check['data']['success'])) {
        $remote_status = (int) ($check['data']['order']['status']['statusID'] ?? 0);
        if ($remote_status === 14) {
          $this->sync_order_status_from_kashpay($order);
          return [
            'result'   => 'success',
            'redirect' => $order->get_checkout_order_received_url(),
          ];
        }

        $pay_url = (string) $order->get_meta('_kashpay_pay_url');
        if ($pay_url !== '') {
          return ['result' => 'success', 'redirect' => $pay_url];
        }
      }

      $order->delete_meta_data('_kashpay_order_id');
      $order->delete_meta_data('_kashpay_pay_url');
      $order->delete_meta_data('_kashpay_status_id');
      $order->save();

      $this->log_info('Existing PosPago reference invalid. Meta cleared to regenerate.');
    }

    $total = (float) $order->get_total();
    if ($total <= 0) {
      wc_add_notice('Monto inválido para PosPago.', 'error');
      return ['result' => 'failure'];
    }

    $expiration_minutes = max(5, (int) $this->get_option('expiration_minutes'));
    $expiration_iso     = gmdate('Y-m-d\TH:i:s', time() + ($expiration_minutes * 60));

    $return_url = add_query_arg([
      'wc-api'   => 'wc_kashpay_return',
      'order_id' => $order->get_id(),
      'key'      => $order->get_order_key(),
    ], home_url('/'));

    $payload = [
      'user' => $cashier,
      'amount' => round($total, 2),
      'sirioID' => $sirio_id,
      'paymentType' => (int) $this->get_option('payment_type'),
      'paymentMethod' => [
        'paymentMethodID' => (int) $this->get_option('payment_method_id'),
      ],
      'currency' => (string) $this->get_option('currency_code'),
      'retrievalReferenceCode' => $this->build_rrc($order),
      'orderType' => ['id' => 2],
      'notificationType' => ['notificationTypeID' => 1],
      'products' => $this->build_products($order),
      'customerInfo' => [
        'firstName'  => $order->get_billing_first_name() ?: 'Cliente',
        'lastName'   => $order->get_billing_last_name() ?: 'WooCommerce',
        'middleName' => '',
        'email'      => $order->get_billing_email() ?: '',
        'phone1'     => $order->get_billing_phone() ?: '',
      ],
      'payInfo' => [
        'unique'      => true,
        'reference'   => 'WC-' . $order->get_id(),
        'description' => 'Pedido WooCommerce #' . $order->get_id(),
        'expiration'  => $expiration_iso,
        'urlCallback' => $return_url,
        'urlImage'    => '',
      ],
      'otherAmount' => 0.0,
      'msi' => false,
      'tip' => false,
    ];

    $this->log_info('Payload create_order: ' . wp_json_encode($payload));

    $res = $this->api()->create_order($payload);

    $this->log_info('Response create_order: ' . wp_json_encode($res));

    if (!$res['ok'] || empty($res['data']['success'])) {
      $msg = 'No se pudo crear el link de pago.';

      if (!empty($res['error']) && stripos($res['error'], 'cURL error 60') !== false) {
        $msg = 'No se pudo conectar con PosPago (error SSL del servidor).';
      }

      if (!empty($res['data']['error'])) {
        $msg .= ' ' . wp_strip_all_tags(print_r($res['data']['error'], true));
      } elseif (!empty($res['data']['raw'])) {
        $msg .= ' Respuesta: ' . wp_strip_all_tags(substr((string)$res['data']['raw'], 0, 180));
      }

      $order->add_order_note('[PosPago] Error creando orden: ' . $msg);
      wc_add_notice($msg, 'error');
      return ['result' => 'failure'];
    }

    $data = $res['data'];

    $kash_order_id = $data['payOrderResponse']['order']['id']
                  ?? $data['payOrderResponse']['id']
                  ?? '';
    $pay_url       = $data['payOrderResponse']['payOrder'] ?? '';
    $form_url      = $data['payOrderResponse']['formUrl'] ?? '';

    if (!$kash_order_id || (!$pay_url && !$form_url)) {
      $order->add_order_note('[PosPago] Respuesta inesperada al crear orden.');
      wc_add_notice('Respuesta inesperada de PosPago (sin URL de pago).', 'error');
      return ['result' => 'failure'];
    }

    $redirect = $form_url ?: $pay_url;

    $order->update_meta_data('_kashpay_order_id', $kash_order_id);
    $order->update_meta_data('_kashpay_pay_url', $redirect);
    $order->update_meta_data('_kashpay_status_id', 13);
    $order->save();

    $order->update_status('pending', '[PosPago] Link de pago generado. Redirigiendo a PosPago.');

    return [
      'result'   => 'success',
      'redirect' => $redirect,
    ];
  }

  // =========================================================================
  //  HELPERS
  // =========================================================================

  private function build_rrc(WC_Order $order): string {
    $base = 'WC' . $order->get_id() . '-' . time();
    $base = preg_replace('/[^A-Za-z0-9\-]/', '', $base);
    return substr($base, 0, 40);
  }

  private function build_products(WC_Order $order): array {
    $items = [];
    foreach ($order->get_items() as $item) {
      $name  = $item->get_name();
      $qty   = (int) $item->get_quantity();
      $total = (float) $item->get_total();
      $unit  = $qty > 0 ? round($total / $qty, 2) : round($total, 2);

      $items[] = [
        'description' => mb_substr($name, 0, 100),
        'category'    => 'woocommerce',
        'count'       => $qty,
        'price'       => $unit,
        'tax'         => (float) $item->get_total_tax(),
      ];
    }

    if (empty($items)) {
      $items[] = [
        'description' => 'Pedido WooCommerce',
        'category'    => 'woocommerce',
        'count'       => 1,
        'price'       => round((float) $order->get_total(), 2),
        'tax'         => (float) $order->get_total_tax(),
      ];
    }

    return $items;
  }

  // =========================================================================
  //  RETURN & WEBHOOK HANDLERS
  // =========================================================================

  public function handle_return() {
    $order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
    $key      = isset($_GET['key']) ? wc_clean(wp_unslash($_GET['key'])) : '';

    if (!$order_id) {
      wp_safe_redirect(wc_get_checkout_url());
      exit;
    }

    $order = wc_get_order($order_id);
    if (!$order) {
      wp_safe_redirect(wc_get_checkout_url());
      exit;
    }

    if ($key && $order->get_order_key() !== $key) {
      $order->add_order_note('[PosPago] Return con order key inválida.');
      wp_safe_redirect(wc_get_checkout_url());
      exit;
    }

    $this->log_info('[Return] Callback recibido para pedido #' . $order_id);
    $this->sync_order_status_from_kashpay($order);

    wp_safe_redirect($order->get_checkout_order_received_url());
    exit;
  }

  public function handle_webhook() {
    $raw  = file_get_contents('php://input');
    $json = json_decode($raw, true);

    $kash_order_id = '';
    if (is_array($json)) {
      $kash_order_id = $json['orderId'] ?? ($json['id'] ?? '');
    }

    if (!$kash_order_id) {
      status_header(200);
      echo 'ok';
      exit;
    }

    $this->log_info('[Webhook] Recibido para kashpay_order_id=' . $kash_order_id);

    $orders = wc_get_orders([
      'limit'      => 1,
      'meta_key'   => '_kashpay_order_id',
      'meta_value' => sanitize_text_field($kash_order_id),
      'orderby'    => 'date',
      'order'      => 'DESC',
    ]);

    if (!empty($orders)) {
      $order = $orders[0];
      $this->sync_order_status_from_kashpay($order);
    }

    status_header(200);
    echo 'ok';
    exit;
  }

  // =========================================================================
  //  AUTO-VERIFICACIÓN
  // =========================================================================

  public function check_order_on_thankyou(int $order_id): void {
    $order = wc_get_order($order_id);
    if (!$order || $order->is_paid() || $order->get_payment_method() !== $this->id) {
      return;
    }
    $this->log_info('[AutoCheck:ThankYou] Verificando pedido #' . $order_id);
    $this->sync_order_status_from_kashpay($order);
  }

  public function check_order_on_view(int $order_id): void {
    $order = wc_get_order($order_id);
    if (!$order || $order->is_paid() || $order->get_payment_method() !== $this->id) {
      return;
    }
    $order_date = $order->get_date_created();
    if ($order_date && (time() - $order_date->getTimestamp()) > 86400) {
      return;
    }
    $this->log_info('[AutoCheck:ViewOrder] Verificando pedido #' . $order_id);
    $this->sync_order_status_from_kashpay($order);
  }

  public function check_pending_orders_for_current_user(): void {
    $user_id = get_current_user_id();
    if (!$user_id) {
      return;
    }
    $transient_key = 'kashpay_check_user_' . $user_id;
    if (get_transient($transient_key)) {
      return;
    }
    set_transient($transient_key, 1, 60);

    $orders = wc_get_orders([
      'limit'          => 5,
      'customer_id'    => $user_id,
      'status'         => ['pending'],
      'payment_method' => $this->id,
      'meta_key'       => '_kashpay_order_id',
      'meta_compare'   => 'EXISTS',
      'date_created'   => '>' . (time() - 7200),
      'orderby'        => 'date',
      'order'          => 'DESC',
    ]);

    if (empty($orders)) {
      return;
    }

    $this->log_info('[AutoCheck:PageLoad] Usuario #' . $user_id . ' - ' . count($orders) . ' pedidos pendientes.');

    foreach ($orders as $order) {
      if (!$order->is_paid()) {
        $this->sync_order_status_from_kashpay($order);
      }
    }
  }

  public function cron_check_pending_orders(): void {
    $orders = wc_get_orders([
      'limit'          => 20,
      'status'         => ['pending', 'on-hold'],
      'payment_method' => $this->id,
      'meta_key'       => '_kashpay_order_id',
      'meta_compare'   => 'EXISTS',
      'date_created'   => '>' . (time() - 86400),
      'orderby'        => 'date',
      'order'          => 'DESC',
    ]);

    if (empty($orders)) {
      return;
    }

    $this->log_info('[Cron] Revisando ' . count($orders) . ' pedidos pendientes.');

    foreach ($orders as $order) {
      if ($order->is_paid()) {
        continue;
      }
      $this->log_info('[Cron] Verificando pedido #' . $order->get_id());
      $this->sync_order_status_from_kashpay($order);
      usleep(500000);
    }
  }

  // =========================================================================
  //  SYNC STATUS
  // =========================================================================

  private function sync_order_status_from_kashpay(WC_Order $order): void {
    $kash_order_id = (string) $order->get_meta('_kashpay_order_id');
    if (!$kash_order_id || $order->is_paid()) {
      return;
    }

    $attempts = 0;
    $status_id = 0;

    while ($attempts < 3) {
      $res = $this->api()->get_order($kash_order_id);

      $this->log_info('[Sync] GET order ' . $kash_order_id . ' attempt=' . ($attempts + 1) . ' status_code=' . ($res['status'] ?? '?'));

      if (!empty($res['ok']) && !empty($res['data']['success'])) {
        $remote = $res['data']['order'] ?? [];
        $status_id = (int) ($remote['status']['statusID'] ?? 0);

        if ($status_id === 14 || $status_id === 13 || $status_id === 15 || $status_id === 17) {
          break;
        }
      }

      sleep(2);
      $attempts++;
    }

    $this->log_info('[Sync] Pedido #' . $order->get_id() . ' statusID=' . $status_id);

    if ($status_id === 14) {
      $order->payment_complete();
      $order->add_order_note('[PosPago] Pago confirmado (statusID=14).');
      if (function_exists('WC') && WC()->cart) {
        WC()->cart->empty_cart();
      }
      return;
    }

    if ($status_id === 15) {
      $order->update_status('failed', '[PosPago] Orden expirada (statusID=15).');
      return;
    }

    if ($status_id === 17) {
      $order->update_status('on-hold', '[PosPago] Pago parcial (statusID=17).');
      return;
    }

    if ($status_id > 0) {
      $order->add_order_note('[PosPago] Estado actual: ' . $status_id);
    }
  }
}